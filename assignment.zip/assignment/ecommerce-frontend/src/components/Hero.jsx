const Hero = () => (
  <div className="bg-blue-600 text-white p-10 rounded-lg text-center mt-4">
    <h1 className="text-4xl font-bold">Welcome to E-Shop</h1>
    <p className="mt-2">Best products just for you!</p>
  </div>
)

export default Hero