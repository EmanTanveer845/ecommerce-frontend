import products from '../data/Products'
import ProductCard from './ProductCard'

const ProductGrid = () => (
  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-4">
    {products.map((p) => (
      <ProductCard key={p.id} product={p} />
    ))}
  </div>
)

export default ProductGrid