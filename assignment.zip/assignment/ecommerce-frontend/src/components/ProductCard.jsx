import { Link } from 'react-router-dom'

const ProductCard = ({ product }) => (
  <div className="border rounded-lg p-4 shadow hover:shadow-lg transition">
    <img src={product.image} alt={product.name} className="w-full h-40 object-cover rounded" />
    <h2 className="font-bold mt-2">{product.name}</h2>
    <p className="text-green-600 font-semibold">Rs {product.price}</p>
    <div className="flex justify-between mt-2">
      <Link to={`/product/${product.id}`} className="bg-blue-600 text-white px-3 py-1 rounded">
        View
      </Link>
    </div>
  </div>
)

export default ProductCard