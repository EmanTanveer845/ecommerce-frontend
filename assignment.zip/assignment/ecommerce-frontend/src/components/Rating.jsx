const Rating = ({ value }) => {
  return (
    <div className="flex space-x-1 text-yellow-400">
      {[...Array(5)].map((_, i) => (
        <span key={i}>{i < value ? '★' : '☆'}</span>
      ))}
    </div>
  )
}

export default Rating