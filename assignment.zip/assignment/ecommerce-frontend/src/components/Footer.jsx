const Footer = () => (
  <footer className="bg-gray-800 text-white p-4 text-center mt-auto">
    &copy; 2026 E-Shop. All rights reserved.
  </footer>
)

export default Footer