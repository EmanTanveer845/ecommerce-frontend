const CategoryFilter = ({ categories, onFilter }) => {
  return (
    <div className="flex space-x-2 mt-4">
      {categories.map((cat) => (
        <button
          key={cat}
          onClick={() => onFilter(cat)}
          className="bg-gray-200 px-3 py-1 rounded hover:bg-gray-300"
        >
          {cat}
        </button>
      ))}
      <button
        onClick={() => onFilter('All')}
        className="bg-gray-200 px-3 py-1 rounded hover:bg-gray-300"
      >
        All
      </button>
    </div>
  )
}

export default CategoryFilter