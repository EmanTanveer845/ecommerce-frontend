const CartSummary = ({ cart }) => {
  const total = cart.reduce((acc, item) => acc + item.price * item.quantity, 0)
  return (
    <div className="p-4 border rounded mt-4">
      <h2 className="font-bold text-xl">Cart Summary</h2>
      <p className="mt-2">Total: Rs {total}</p>
      <button className="bg-green-600 text-white px-4 py-2 mt-2 rounded">
        Checkout
      </button>
    </div>
  )
}

export default CartSummary