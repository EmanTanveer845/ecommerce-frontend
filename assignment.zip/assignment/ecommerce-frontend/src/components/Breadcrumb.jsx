import { Link } from 'react-router-dom'

const Breadcrumb = ({ path = [] }) => (
  <div className="text-gray-600 text-sm mb-4">
    <Link to="/">Home</Link>
    {path.map((p, i) => (
      <span key={i}>
        {' / '}
        {p.link ? <Link to={p.link}>{p.name}</Link> : p.name}
      </span>
    ))}
  </div>
)

export default Breadcrumb