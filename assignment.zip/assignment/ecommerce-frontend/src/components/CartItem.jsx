const CartItem = ({ item, updateQuantity, removeFromCart }) => (
  <div className="flex justify-between items-center border-b p-4">
    <img src={item.image} alt={item.name} className="w-20 h-20 object-cover rounded" />
    <div className="flex-1 ml-4">
      <h2 className="font-bold">{item.name}</h2>
      <p>Rs {item.price}</p>
      <input
        type="number"
        value={item.quantity}
        min="1"
        onChange={(e) => updateQuantity(item.id, parseInt(e.target.value))}
        className="border p-1 w-20 mt-2"
      />
    </div>
    <button
      onClick={() => removeFromCart(item.id)}
      className="bg-red-600 text-white px-3 py-1 rounded"
    >
      Remove
    </button>
  </div>
)

export default CartItem