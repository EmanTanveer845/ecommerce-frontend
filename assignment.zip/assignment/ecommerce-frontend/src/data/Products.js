const products = [
  { id: 1, name: 'Wireless Headphones', price: 2500, category: 'Electronics', rating: 4, image: '/images/headphone.jpg' },
  { id: 2, name: 'Smart Watch', price: 4500, category: 'Electronics', rating: 5, image: '/images/smartwatch.jpg' },
  { id: 3, name: 'Running Shoes', price: 3200, category: 'Fashion', rating: 3, image: '/images/runningshoes.jpg' },
  { id: 4, name: 'Sunglasses', price: 1500, category: 'Fashion', rating: 4, image: '/images/sunglasses.jpg' },
  { id: 5, name: 'Laptop', price: 55000, category: 'Electronics', rating: 5, image: '/images/laptop.jpg' },
  { id: 6, name: 'Backpack', price: 2000, category: 'Accessories', rating: 4, image: '/images/backpack.jpg' },
  { id: 7, name: 'T-Shirt', price: 800, category: 'Fashion', rating: 3, image: '/images/tshirt.jpg' },
  { id: 8, name: 'Jeans', price: 1500, category: 'Fashion', rating: 4, image: '/images/jeans.jpg' },
  { id: 9, name: 'Phone Case', price: 500, category: 'Accessories', rating: 4, image: '/images/phonecase.jpg' },
  { id: 10, name: 'Bluetooth Speaker', price: 3000, category: 'Electronics', rating: 5, image: '/images/bluetoothspeaker.jpg' },
  { id: 11, name: 'Cap', price: 400, category: 'Fashion', rating: 3, image: '/images/cap.jpg' },
  { id: 12, name: 'Wallet', price: 1200, category: 'Accessories', rating: 4, image: '/images/wallet.jpg' },
  { id: 13, name: 'Perfume', price: 2500, category: 'Accessories', rating: 5, image: '/images/perfume.jpg' },
  { id: 14, name: 'Tablet', price: 30000, category: 'Electronics', rating: 4, image: '/images/tablet.jpg' },
  { id: 15, name: 'Shoes', price: 3500, category: 'Fashion', rating: 4, image: '/images/shoes.jpg' }
]

export default products