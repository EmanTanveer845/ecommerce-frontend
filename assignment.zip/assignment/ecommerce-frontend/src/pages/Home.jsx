import Hero from '../components/Hero'
import ProductGrid from '../components/ProductGrid'

const Home = () => (
  <div className="p-6">
    <Hero />
    <h2 className="text-2xl font-bold mt-6">Featured Products</h2>
    <ProductGrid />
  </div>
)

export default Home