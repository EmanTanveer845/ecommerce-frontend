import { useState } from 'react'
import productsData from '../data/Products'
import ProductCard from '../components/ProductCard'
import SearchBar from '../components/SearchBar'
import CategoryFilter from '../components/CategoryFilter'

const Products = () => {
  const [products, setProducts] = useState(productsData)

  const categories = [...new Set(productsData.map((p) => p.category))]

  const handleSearch = (query) => {
    setProducts(productsData.filter((p) => p.name.toLowerCase().includes(query.toLowerCase())))
  }

  const handleFilter = (category) => {
    if (category === 'All') setProducts(productsData)
    else setProducts(productsData.filter((p) => p.category === category))
  }

  return (
    <div className="p-6">
      <SearchBar onSearch={handleSearch} />
      <CategoryFilter categories={categories} onFilter={handleFilter} />
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-4">
        {products.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </div>
  )
}

export default Products