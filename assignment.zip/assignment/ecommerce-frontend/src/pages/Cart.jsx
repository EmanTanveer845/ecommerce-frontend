import { useContext } from 'react'
import { CartContext } from '../context/CartContext'
import CartItem from '../components/CartItem'
import CartSummary from '../components/CartSummary'

const Cart = () => {
  const { cart, updateQuantity, removeFromCart } = useContext(CartContext)

  if (cart.length === 0) return <p className="p-6">Your cart is empty!</p>

  return (
    <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
      <div>
        {cart.map((item) => (
          <CartItem key={item.id} item={item} updateQuantity={updateQuantity} removeFromCart={removeFromCart} />
        ))}
      </div>
      <CartSummary cart={cart} />
    </div>
  )
}

export default Cart