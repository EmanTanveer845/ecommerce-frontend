import { useParams } from 'react-router-dom'
import products from '../data/Products'
import { useContext } from 'react'
import { CartContext } from '../context/CartContext'

const ProductDetails = () => {
  const { id } = useParams()
  const { addToCart } = useContext(CartContext)
  const product = products.find((p) => p.id === parseInt(id))

  if (!product) return <p>Product not found!</p>

  return (
    <div className="p-6 flex flex-col md:flex-row gap-6">
      <img src={product.image} alt={product.name} className="w-full md:w-1/2 h-auto object-contain" />
      <div className="flex-1">
        <h1 className="text-3xl font-bold">{product.name}</h1>
        <p className="text-green-600 font-semibold mt-2">Rs {product.price}</p>
        <p className="mt-2">Rating: {product.rating} ⭐</p>
        <button
          onClick={() => addToCart(product)}
          className="bg-blue-600 text-white px-4 py-2 mt-4 rounded"
        >
          Add to Cart
        </button>
      </div>
    </div>
  )
}

export default ProductDetails